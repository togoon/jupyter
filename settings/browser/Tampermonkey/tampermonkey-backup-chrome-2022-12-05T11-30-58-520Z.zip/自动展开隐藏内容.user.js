// ==UserScript==
// @name         自动展开隐藏内容
// @namespace    Auto show hidden contents.
// @version      1.47
// @description  Auto show the hidden contents.
// @author       Rocy

// @match        *://3g.163.com/.*?/article/*
// @match        *://*.360doc.com/content/*
// @match        *://*.36kr.com/p/*
// @match        *://*.5axxw.com/questions/content/*

// @match        *://baijiahao.baidu.com/s*
// @match        *://jingyan.baidu.com/article/*
// @match        *://mbd.baidu.com/newspage/data/dtlandingwise*
// @match        *://mbd.baidu.com/newspage/data/landingshare*
// @match        *://tieba.baidu.com/p/*
// @match        *://wenku.baidu.com/view/*
// @match        *://zhidao.baidu.com/question/*
// @match        *://*.bilibili.com/read/mobile?id=*

// @match        *://blog.didispace.com/*

// @match        *://m.huxiu.com/article/*

// @match        *://news.ifeng.com/c/*
// @match        *://*.it1352.com/*

// @match        *://*.jb51.cc/*
// @match        *://*.jianshu.com/p/*

// @match        *://*.k4china.com/*

// @match        *://*.q578.com/*
// @match        *://xw.qq.com/amphtml/*
// @match        *://xw.qq.com/cmsid/*

// @match        *://k.sina.cn/*
// @match        *://3g.k.sohu.com/t/*
// @match        *://m.sohu.com/a/*

// @match        *://*.tofacebook.com/view/*

// @match        *://m.wang1314.com/doc/webapp/topic/*
// @match        *://weibo.com/ttarticle/p/show*
// @match        *://card.weibo.com/article/m/show/id/*

// @match        *://*.xcc.com/newdetail/*

// @match        *://*.yiidian.com/*

// @match        *://*.zhihu.com/question/*

// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_registerMenuCommand
// @grant        GM_unregisterMenuCommand
// @license      GPL-3.0
// ==/UserScript==

(function () {
  "use strict";

  /*
   * 不想写注释然后被官方特别轻易地反制...
   * 脚本并不复杂，为了避免各种网站删减或更换JS框架，在实现中尽可能地使用了原生JS
   * 能看懂的自然能看懂，看不懂的写再多注释也没用...
   *
   * 如果贵公司知道了我们脚本的存在并打算反制的话，那么看到这的你估计就是这个工作的实行者了
   * 那么不妨来加我们群来和我们聊聊天，交流交流，又能摸鱼又能快速达成KPI，何乐而不为呢？
   */

  let settings = {
    interval_time: 50,
    interval_max_time: 5000,
    enable_notification: true,
    enable_notification_submenu_id: -1,
    enable_notification_submenu_texts: ["✅开启弹窗显示", "❎关闭弹窗显示"],
  };

  let message_data = {
    box: null,
    message_ele: null,
    timeout: null,
  };

  let prev_handled_count = 0;
  let handled_count = 0;

  let platforms = [
    // number
    {
      name: "网易移动版文章",
      include_regex: [/^.*:\/\/3g.163.com\/.*?\/article\/.*/],
      auto_height_elements_item: [
        {
          type: "element",
          value: "article",
        },
      ],
      hide_click_item: [
        {
          type: "class",
          value: "show_article js-show-article",
        },
      ],
    },
    {
      name: "360个人图书馆",
      include_regex: [/^.*:\/\/.*.360doc.com\/content\/.*/],
      custom_item: [
        {
          already_run: false,
          callback() {
            let eles = $("body.articleMaxH");
            if (eles.length > 0) {
              eles.removeClass("articleMaxH");
              return eles.length;
            }

            return 0;
          },
        },
        {
          already_run: false,
          callback() {
            if (ReShowAll) {
              ReShowAll();
              return 1;
            }

            return 0;
          },
        },
      ],
    },
    {
      name: "36氪文章移动页",
      include_regex: [/^.*:\/\/.*?36kr.com\/p\/.*/],
      delete_elements_item: [
        {
          type: "class",
          value: "tips-mask",
        },
        {
          type: "class",
          value: "tips-content",
        },
        {
          type: "class",
          value: "article-goapp",
        },
      ],
      auto_height_elements_item: [
        {
          type: "id",
          value: "body-content",
        },
      ],
      custom_item: [
        {
          already_run: false,
          callback() {
            if (getComputedStyle(document.body).overflow == "hidden") {
              document.body.style.setProperty("overflow", "auto", "important");
              return 1;
            }
            return 0;
          },
        },
        {
          already_run: false,
          callback() {
            let goapp_swiper = document.getElementsByClassName(
              "article-top-swiper-goapp"
            );
            if (goapp_swiper != null && goapp_swiper.length > 0) {
              goapp_swiper = goapp_swiper[0];
              goapp_swiper.style.setProperty("dispaly", "none", "important");
              goapp_swiper.style.setProperty("opacity", "0", "important");
              goapp_swiper.style.setProperty(
                "visibility",
                "hidden",
                "important"
              );
            }
          },
        },
      ],
    },
    {
      name: "",
      include_regex: [/^.*:\/\/.*.5axxw.com\/questions\/content\/.*/],
      delete_elements_item: [
        {
          type: "id",
          value: "gzh-modal-wrap"
        }
      ]
    },

    //b
    {
      name: "百家号文章&百度文章",
      include_regex: [
        //百家号文章
        /^.*:\/\/baijiahao.baidu.com\/s.*/,
        //百度文章
        /^.*:\/\/mbd.baidu.com\/newspage\/data\/landingshare.*/,
      ],
      delete_elements_item: [
        {
          type: "class",
          value: "layer-wrap",
        },
        {
          type: "class",
          value: "headDeflectorContainer",
        },
        {
          type: "class",
          value: "oPadding",
        },
      ],
      auto_height_elements_item: [
        {
          type: "class",
          value: "mainContent",
        },
      ],
      hide_click_item: [
        {
          type: "class",
          value: "ariaicon ariaicon-exit",
          delay: 500,
        },
      ],
      custom_item: [
        {
          already_run: false,
          callback() {
            if (getComputedStyle(document.body).overflow == "hidden") {
              document.body.style.setProperty("overflow", "auto", "important");
              return 1;
            }
            return 0;
          },
        },
        {
          loop: true,
          callback() {
            let flag = false;
            let app_install_bars_children =
              document.getElementsByClassName("other")[0];
            if (typeof app_install_bars_children == "undefined") {
              app_install_bars_children = document.getElementsByClassName(
                "baike_lemma_bottom_tashuo"
              )[0];
            }
            app_install_bars_children = app_install_bars_children?.children;
            !app_install_bars_children && (app_install_bars_children = [])

            for (let tmp_ele of app_install_bars_children) {
              if (
                tmp_ele.style.left == "50%" &&
                tmp_ele.style.transform == "translate(-50%, 0%)" &&
                window.getComputedStyle(tmp_ele).position == "fixed"
              ) {
                tmp_ele.remove();
                flag = true;
              }
            }

            return flag;
          },
        },
      ],
    },
    {
      name: "百度经验内容",
      include_regex: [/^.*:\/\/jingyan.baidu.com\/article\/.*/],
      delete_elements_item: [
        {
          type: "class",
          value: "read-whole-mask",
        },
      ],
      auto_height_elements_item: [
        {
          type: "class",
          value: "exp-content-container fold",
        },
      ],
      hide_click_item: [
        {
          type: "class",
          value: "ariaicon ariaicon-exit",
          delay: 500,
        },
      ],
    },
    {
      name: "百度个人动态",
      include_regex: [/^.*:\/\/mbd.baidu.com\/newspage\/data\/dtlandingwise.*/],
      delete_elements_item: [
        {
          type: "class",
          value: "layer-wrap",
        },
        {
          type: "class",
          value: "height-fold",
        },
        {
          type: "class",
          value: "headDeflectorContainer",
        },
      ],
      auto_height_elements_item: [
        {
          type: "class",
          value: "dynamic-item",
        },
      ],
      hide_click_item: [
        {
          type: "class",
          value: "ariaicon ariaicon-exit",
          delay: 500,
        },
      ],
      custom_item: [
        {
          already_run: false,
          callback() {
            if (getComputedStyle(document.body).overflow == "hidden") {
              document.body.style.setProperty("overflow", "auto", "important");
              return 1;
            }
            return 0;
          },
        },
      ],
    },
    {
      name: "百度贴吧",
      include_regex: [/^.*:\/\/tieba.baidu.com\/p\/.*/],
      delete_elements_item: [
        {
          type: "class",
          value: "tb-backflow-defensive",
        },
        {
          type: "class",
          value: "nav-bar",
        },
      ],
      hide_click_item: [
        {
          type: "class",
          value: "replace_tip",
        },
        {
          type: "class",
          value: "ariaicon ariaicon-exit",
          delay: 500,
        },
      ],
      custom_item: [
        {
          already_run: false,
          callback() {
            document.body.style.overflow = "auto";
            return 1;
          },
        },
      ],
    },
    {
      name: "百度文库文章",
      include_regex: [/^.*:\/\/wenku.baidu.com\/view\/.*/],
      delete_elements_item: [
        {
          type: "class",
          value: "fold-page-content",
        },
        {
          type: "class",
          value: "try-end-fold-page",
        },
      ],
      auto_height_elements_item: [
        {
          type: "id",
          value: "reader-container",
        },
      ],
      hide_click_item: [
        {
          type: "class",
          value: "ariaicon ariaicon-exit",
          delay: 500,
        },
      ],
    },
    {
      name: "百度知道",
      include_regex: [/^.*:\/\/zhidao.baidu.com\/question\/.*/],
      delete_elements_item: [
        {
          type: "class",
          value: "wgt-best-mask",
        },
        {
          type: "class",
          value: "wgt-answers-mask",
        },
        {
          type: "class",
          value: "w-detail-display-btn",
        },
      ],
      auto_height_elements_item: [
        {
          type: "class",
          value: "best-text mb-10",
        },
        {
          type: "class",
          value: "answer-text mb-10",
        },
        {
          type: "class",
          value: "w-detail-container w-detail-index",
        },
      ],
      hide_click_item: [
        {
          type: "id",
          value: "show-answer-hide",
        },
        {
          type: "class",
          value: "show-hide-dispute",
        },
        {
          type: "class",
          value: "ariaicon ariaicon-exit",
          delay: 500,
        },
        {
          type: "class",
          value: "wgt-question-desc-action",
        },
        {
          type: "class",
          value: "reply-repeat-more",
        },
      ],
      hide_tap_item: [
        {
          type: "class",
          value: "show-more-replies",
        },
        {
          type: "class",
          value: "expend-fold-answer",
        },
      ],
    },
    {
      name: "BiliBili文章移动版",
      include_regex: [/^.*:\/\/.*.bilibili.com\/read\/mobile\?id=.*/],
      hide_click_item: [
        {
          type: "class",
          value: "read-more",
        },
      ],
    },

    //d
    {
      name: "程序猿DD",
      include_regex: [/^.*:\/\/blog.didispace.com\/.*/],
      delete_elements_item: [
        {
          type: "id",
          value: "read-more-wrap",
        },
      ],
      auto_height_elements_item: [
        {
          type: "class",
          value: "article article-type-post lock",
        },
      ],
    },

    //h
    {
      name: "虎嗅文章",
      include_regex: [/^.*:\/\/m.huxiu.com\/article\/.*/],
      delete_elements_item: [
        {
          type: "class",
          value: "article-detail-swiper-container",
        },
        {
          type: "class",
          value: "fresh-article-wrap",
        },
      ],
      auto_height_elements_item: [
        {
          type: "class",
          value: "js-mask-box",
        },
      ],
    },

    //i
    {
      name: "凤凰网",
      include_regex: [/^.*:\/\/news.ifeng.com\/c\/.*/],
      custom_item: [
        {
          already_run: false,
          callback() {
            let eles = GetSimilarElement(
              document.getElementById("root"),
              "tip"
            );
            if (eles.length > 0) {
              return DelEles(eles);
            }

            return 0;
          },
        },
        {
          already_run: false,
          callback() {
            let flag = false;
            let eles = GetSimilarElement(
              document.getElementById("root"),
              "link"
            );
            if (eles.length > 0) {
              return DelEles(eles);
            }

            return 0;
          },
        },
        {
          already_run: false,
          callback() {
            let flag = false;
            let eles = GetSimilarElement(
              document.getElementById("root"),
              "bottom_box"
            );
            if (eles.length > 0) {
              return DelEles(eles);
            }

            return 0;
          },
        },
        {
          already_run: false,
          callback() {
            let eles = GetSimilarElement(
              document.getElementById("root"),
              "more"
            );
            if (eles.length > 0) {
              return DelEles(eles);
            }

            return 0;
          },
        },
        {
          already_run: false,
          callback() {
            let eles = GetSimilarElement(
              document.getElementById("root"),
              "main_content"
            );
            if (eles.length > 0) {
              return AutoHeight(eles);
            }

            return 0;
          },
        },
      ],
    },
    {
      name: "IT1352文章",
      include_regex: [/^.*:\/\/.*?it1352.com\/.*/],
      custom_item: [
        {
          already_run: false,
          callback() {
            let it1352_main = $(".arc-body-main");
            let it1352_main_more = $(".arc-body-main-more");
            if (
              it1352_main &&
              it1352_main_more &&
              it1352_main.length &&
              it1352_main_more.length
            ) {
              $(".arc-body-main").css("height", "auto");
              $(".arc-body-main-more").remove();
              return 1;
            } else return 0;
          },
        },
      ],
    },

    //j
    {
      name: "编程之家",
      include_regex: [/^.*:\/\/.*?jb51.cc\/.*/],
      delete_elements_item: [
        {
          type: "id",
          value: "read-more-wrap",
        },
      ],
      auto_height_elements_item: [
        {
          type: "id",
          value: "container",
        },
      ],
    },
    {
      name: "简书文章",
      include_regex: [/^.*:\/\/.*?jianshu.com\/p\/.*/],
      delete_elements_item: [
        {
          type: "class",
          value: "collapse-tips",
        },
        {
          type: "class",
          value: "download-app-guidance",
        },
        {
          type: "class",
          value: "call-app-btn",
        },
      ],
      auto_height_elements_item: [
        {
          type: "class",
          value: "collapse-free-content",
        },
      ],
      hide_click_item: [
        {
          type: "class",
          value: "ant-btn nP21pp",
        },
      ],
      custom_item: [
        {
          already_run: false,
          callback() {
            let style_ele = document.createElement("style");
            style_ele.innerHTML =
              "#note-show .content .show-content-free .collapse-free-content:after{content:unset !important}";
            document.body.append(style_ele);
            return 1;
          },
        },
      ],
    },

    //k
    {
      name: "科中资源网",
      include_regex: [/^.*:\/\/.*?k4china.com\/.*/],
      hide_click_item: [
        {
          type: "class",
          value: "readmore",
        },
      ],
    },

    //q
    {
      name: "品阅网",
      include_regex: [/^.*:\/\/.*.q578.com\/.*/],
      hide_click_item: [
        {
          type: "class",
          value: "read_more_btn",
        },
      ],
    },
    {
      name: "腾讯网文章",
      include_regex: [/^.*:\/\/xw.qq.com\/amphtml\/.*/],
      delete_elements_item: [
        {
          type: "class",
          value: "ct-unfold folded",
        },
      ],
      auto_height_elements_item: [
        {
          type: "class",
          value: "article-main fold",
        },
      ],
    },
    {
      name: "腾讯新闻移动版文章",
      include_regex: [/^.*:\/\/xw.qq.com\/cmsid\/.*/],
      delete_elements_item: [
        {
          type: "class",
          value: "collapseWrapper",
        },
        {
          type: "class",
          value: "mask",
        },
      ],
      auto_height_elements_item: [
        {
          type: "id",
          value: "article_body",
        },
      ],
    },

    //s
    {
      name: "新浪文章",
      include_regex: [/^.*:\/\/k.sina.cn\/.*/],
      delete_elements_item: [
        {
          type: "id",
          value: "float-btn",
        },
        {
          type: "id",
          value: "artFoldBox",
        },
      ],
      auto_height_elements_item: [
        {
          type: "class",
          value: "s_card z_c1",
        },
      ],
    },
    {
      name: "搜狐移动版文章",
      include_regex: [
        /^.*:\/\/3g.k.sohu.com\/t\/.*/,
        /^.*:\/\/m.sohu.com\/a\/.*/,
      ],
      hide_click_item: [
        {
          type: "id",
          value: "at-cnt-rest",
        },
        {
          type: "id",
          value: "artLookAll",
        },
      ],
    },

    //t
    {
      name: "脸书百科",
      include_regex: [/^.*:\/\/.*.tofacebook.com\/view\/.*/],
      hide_click_item: [
        {
          type: "class",
          value: "btn btn-fulltext",
          delay: 100
        },
      ],
    },

    //w
    {
      name: "好网角收藏夹",
      include_regex: [/^.*:\/\/m.wang1314.com\/doc\/webapp\/topic\/.*/],
      hide_click_item: [
        {
          type: "id",
          value: "readAll",
        },
      ],
    },
    {
      name: "微博文章",
      include_regex: [/^.*:\/\/weibo.com\/ttarticle\/p\/show.*/],
      delete_elements_item: [
        {
          type: "class",
          value: "btn_line W_tc W_f14 W_fb",
        },
      ],
      auto_height_elements_item: [
        {
          type: "class",
          value: "WB_editor_iframe_new",
        },
      ],
    },
    {
      name: "微博头条文章",
      include_regex: [/^.*:\/\/card.weibo.com\/article\/m\/show\/id\/.*/],
      delete_elements_item: [
        {
          type: "class",
          value: "f-art-opt",
        },
      ],
      auto_height_elements_item: [
        {
          type: "class",
          value: "f-art",
        },
      ],
    },

    //x
    {
      name: "芯查查资讯文章",
      include_regex: [/^.*:\/\/.*?xcc.com\/newdetail\/.*/],
      hide_click_item: [
        {
          type: "class",
          value: "el-button el-button--primary",
        },
      ],
    },

    //y
    {
      name: "一点教程",
      include_regex: [/^.*:\/\/.*?yiidian.com\/.*/],
      delete_elements_item: [
        {
          type: "id",
          value: "read-more-mask",
        },
        {
          type: "id",
          value: "read-more-wrap",
        },
      ],
      auto_height_elements_item: [
        {
          type: "id",
          value: "yArticle",
        },
      ],
    },

    //z
    {
      name: "知乎内容",
      include_regex: [/.*:\/\/.*?zhihu.com\/question\/.*/],
      hide_elements_item: [
        {
          type: "class",
          value: "Modal-enter-done",
        },
        {
          type: "class",
          value: "ModalWrap",
        },
        {
          type: "class",
          value: "SkipModal",
        },
        {
          type: "class",
          value: "OpenInApp",
        },
        {
          type: "class",
          value: "ContentItem-expandButton",
        },
      ],
      auto_height_elements_item: [
        {
          type: "class",
          value: "RichContent-inner",
        },
      ],
      custom_item: [
        {
          already_run: false,
          callback() {
            if (
              getComputedStyle(document.documentElement).overflow == "hidden"
            ) {
              document.documentElement.style.setProperty(
                "overflow",
                "auto",
                "important"
              );
              return 1;
            }
            return 0;
          },
        },
        {
          already_run: false,
          callback() {
            if (getComputedStyle(document.body).overflow == "hidden") {
              document.body.style.setProperty("overflow", "auto", "important");
              return 1;
            }
            return 0;
          },
        },
        {
          already_run: false,
          callback() {
            let view_all = document.getElementsByClassName(
              "ViewAll-QuestionMainAction"
            );
            if (view_all.length > 0) {
              view_all[0].onclick = function () {
                setTimeout(function () {
                  InitRunable();
                }, 500);
              };
              return 1;
            }
            return 0;
          },
        },
        {
          loop: true,
          callback() {
            let rich_eles =
              document.getElementsByClassName("RichContent-inner");
            if (rich_eles.length > 0) {
              let counter = 0;
              for (let rich_ele of rich_eles) {
                if (rich_ele.style["-webkit-mask-image"] != "none") {
                  rich_ele.style.setProperty("-webkit-mask-image", "none");
                  ++counter;
                }
              }

              return counter > 0;
            }

            return 0;
          },
        },
      ],
    },
  ];

  let run_times = 0;

  Init();
  InitMessageArea();
  InitRunable();

  function InitRunable() {
    let handler = GetPlatform();
    let interval = setInterval(() => {
      if (handler.delete_elements_item) {
        for (let delete_item of handler.delete_elements_item) {
          let delete_eles = GetItemElement(delete_item);
          if (delete_eles.length <= 0) {
            continue;
          }

          handled_count += DelEles(delete_eles);
        }
      }

      if (handler.hide_elements_item) {
        for (let hide_item of handler.hide_elements_item) {
          let hide_eles = GetItemElement(hide_item);
          if (hide_eles.length <= 0) {
            continue;
          }

          handled_count += HideEles(hide_eles);
        }
      }

      if (handler.auto_height_elements_item) {
        for (let height_item of handler.auto_height_elements_item) {
          let height_eles = GetItemElement(height_item);
          if (height_eles.length <= 0) {
            continue;
          }

          handled_count += AutoHeightEles(height_eles);
        }
      }

      if (handler.hide_click_item) {
        for (let click_item of handler.hide_click_item) {
          let click_eles = GetItemElement(click_item);
          if (click_eles.length > 0) {
            for (let click_ele of click_eles) {
              if (
                click_ele != null &&
                click_ele.getAttribute("opened") != "yes"
              ) {
                setTimeout(function () {
                  click_ele.click();
                }, click_item.delay ?? 0);
                click_ele.setAttribute("opened", "yes");
                ++handled_count;
              }
            }
          }
        }
      }

      if (handler.hide_tap_item) {
        for (let tap_item of handler.hide_tap_item) {
          let tap_eles = GetItemElement(tap_item);
          if (tap_eles.length > 0) {
            for (let tap_ele of tap_eles) {
              if (tap_ele != null && tap_ele.getAttribute("opened") != "yes") {
                try {
                  $(tap_ele).trigger("tap");
                  tap_ele.setAttribute("opened", "yes");
                  ++handled_count;
                } catch (ex) {
                  console.error(ex);
                }
              }
            }
          }
        }
      }

      if (handler.custom_item && !handler.custom_item.already_run) {
        for (let custom_item of handler.custom_item) {
          let custom_success_counter = 0;
          if (!custom_item.already_run || custom_item.loop) {
            custom_success_counter = custom_item.callback();
            if (!custom_item.loop && custom_success_counter) {
              custom_item.already_run = true;
            }
          }

          handled_count += custom_success_counter ?? 0;
        }
      }

      if (settings.enable_notification && handled_count && prev_handled_count != handled_count) {
        prev_handled_count = handled_count;
        ShowMessage(`已与页面斗智斗勇 ${handled_count}次`);
      }

      if (++run_times >= settings.interval_max_time / settings.interval_time) {
        clearInterval(interval);
      }
    }, settings.interval_time);
  }

  function Init() {
    settings.enable_notification = GM_getValue("enable_notification", true);
    ResetNotificationSubMenu();

    function ResetNotificationSubMenu() {
      if (settings.enable_notification_submenu_id >= 0) {
        GM_unregisterMenuCommand(settings.enable_notification_submenu_id);
      }

      settings.enable_notification_submenu_id = GM_registerMenuCommand(
        settings.enable_notification_submenu_texts[
          settings.enable_notification ? 1 : 0
        ],
        function () {
          settings.enable_notification = !settings.enable_notification;
          GM_setValue("enable_notification", settings.enable_notification);
          ShowMessage(`斗智斗勇弹窗已${settings.enable_notification ? '开启' : '关闭'}`);

          ResetNotificationSubMenu();
        }
      );
    }
  }

  function InitMessageArea() {
    let css = document.createElement("style");
    css.innerHTML =
      ".__auto-show-message-box{position:fixed;top:0;right:0;z-index:999999}" +
      ".__auto-show-message{position:absolute;top:35px;left:10px;width:250px;height:2.5em;line-height:2.5em;overflow:hidden;padding:0 .5em;background:#282C34;font-size:14px;color:#fff;border-radius:2px;box-shadow:rgba(0,0,0,.5) 0 0 5px;text-shadow:none;opacity:0;transition:all .3s}" +
      ".__auto-show-message.__show{left:-300px;opacity:1}";
    message_data.box = document.createElement("div");
    message_data.box.className = "__auto-show-message-box";
    message_data.message_ele = document.createElement("div");
    message_data.message_ele.className = "__auto-show-message";
    message_data.box.append(message_data.message_ele);
    document.body.append(css);
    document.body.append(message_data.box);
  }

  function ShowMessage(dom) {
    dom = "【自动展开】" + dom;
    message_data.message_ele.innerHTML = dom;
    message_data.message_ele.className = "__auto-show-message __show";
    message_data.timeout && clearTimeout(message_data.timeout);
    message_data.timeout = setTimeout(() => {
      message_data.message_ele.className = "__auto-show-message";
    }, 2000);
    console.log("%c" + dom, "color:#f80");
  }

  function GetPlatform() {
    for (let plat_obj of platforms) {
      for (let platform of plat_obj.include_regex) {
        if (platform.test(location.href)) {
          return plat_obj;
        }
      }
    }
  }

  function GetItemElement(item) {
    if (item.type == "class") {
      return document.getElementsByClassName(item.value);
    } else if (item.type == "id") {
      let id_ele = document.getElementById(item.value);
      return id_ele ? [id_ele] : [];
    } else if (item.type == "element") {
      return document.getElementsByTagName(item.value);
    }

    return [];
  }

  function DelEles(delete_eles) {
    var counter = 0;
    for (let delete_ele of delete_eles) {
      delete_ele.remove();
      ++counter;
    }
    return counter;
  }

  function HideEles(hide_eles) {
    var counter = 0;
    for (let hide_ele of hide_eles) {
      if (hide_ele.style.display != "none") {
        hide_ele.style.setProperty("display", "none", "important");
        ++counter;
      }
    }
    return counter;
  }

  function AutoHeightEles(auto_height_eles) {
    var counter = 0;
    for (let auto_height_ele of auto_height_eles) {
      if (
        auto_height_ele.style.height == "unset" &&
        auto_height_ele.style.minHeight == "unset" &&
        auto_height_ele.style.maxHeight == "unset"
      ) {
        continue;
      }

      auto_height_ele.style.height = "unset";
      auto_height_ele.style.minHeight = "unset";
      auto_height_ele.style.maxHeight = "unset";
      ++counter;
    }
    return counter;
  }

  function GetSimilarElement(parent_ele, class_name) {
    let result_eles = [];
    for (let child_ele of parent_ele.children) {
      if (child_ele.className.indexOf(class_name) > -1) {
        result_eles.push(child_ele);
      }
      let child_result = GetSimilarElement(child_ele, class_name);
      for (let r_temp of child_result) {
        result_eles.push(r_temp);
      }
    }
    return result_eles;
  }
})();
