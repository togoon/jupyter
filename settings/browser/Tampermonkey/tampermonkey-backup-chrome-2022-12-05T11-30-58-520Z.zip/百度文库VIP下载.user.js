// ==UserScript==
// @name         百度文库VIP下载
// @namespace    http://120.25.170.209/
// @version      0.1
// @description  破解百度文库VIP专享下载，基于html22.com，会新窗口打开。
// @author       Czruby
// @match        *://wenku.baidu.com/view/*
// @icon         https://www.google.com/s2/favicons?domain=html22.com
// @grant        none
// ==/UserScript==

(function(){
    'use strict'
window.addEventListener('load', () => {
    addButton('下载跳转', selectReadFn)
    })
function addButton(text, onclick, cssObj) {
        cssObj = cssObj || {position: 'absolute', bottom: '50%', left:'2%', 'z-index': 3, width:'50px',position: 'fixed'}
        let button = document.createElement('button'), btnStyle = button.style
        document.body.appendChild(button)
        button.innerHTML = text
        button.onclick = onclick
        Object.keys(cssObj).forEach(key => btnStyle[key] = cssObj[key])
        return button
    }
function selectReadFn() {
     window.open("http://www.html22.com/d/?url="+location.href);
}
}())