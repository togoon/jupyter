// ==UserScript==
// @name 美化字体, 滚动条, 指向图片发光, 文本选中样式
// @description 美化字体, 滚动条, 指向图片发光, 文本选中样式。
// @author jxb
// @version 1.2
// @match *://*/*
// @grant none
// @run-at document-start
// @namespace https://greasyfork.org/users/694396
// ==/UserScript==

-function() {
	'use strict';
	try {
		if (self != top) {} else {
			if (document.readyState || document.childNodes || document.onreadystatechange) {
				jiangxiaobai()
			} else {
				jiangxiaobai()
			}
			function jiangxiaobai() {
				let css = '',
					obj = location.href;
				if (!(obj.match(/^https?:\/\/(?:greasyfork|(?:\d{1,3}\.){3})\./i))) css += ['' + 
				/* 美化字体 */
				':not([class*=-chevron-]):not([id*=-chevron-]):not([class*=Logo]):not([id*=Logo]):not([class*=ico]):not([id*=ico]):not([class*=ui]):not([id*=ui]):not([class*=font]):not([id*=font]):not([class*=logo]):not([id*=logo]):not([class*=pre]):not([id*=pre]):not([class*=next]):not([id*=next]):not([class*=close]):not([id*=close]):not([class*=_]):not([id*=_]):not(.fa):not(.fas):not(icon):not([src]):not(hr):not(br):not(ui):not(placeholder):not(iframe):not(embed):not(object):not(video):not(span):not(head):not(meta):not(title):not(link):not(script):not(style):not(img):not(svg):not(d):not(i):not(s):not(p){font-weight:bolder;font-family:Microsoft YaHei,VideoJS,Verdana,Roboto,arial,FontAwesome,YouTube Noto，myfont，Source Han Sans SC，Noto Sans CJK SC，HanHei SC，sans-serif，icomoon，Icons，brand-icons，Material Icons，Material Icons Extended，Glyphicons Halflings,simhei,Monaco,Courier New,Trebuchet MS,Time News Roman,Tahoma,Comic Sans MS,Impact,MingLiU,PMingLiU,MS UI Gothic,DengXian，Segoe UI，Lucida Grande，Helvetica，FreeSans，Arimo，Droid Sans，wenquanyi micro hei，Hiragino Sans GB，Hiragino Sans GB W3,Georgia;-webkit-font-smoothing:antialiased;text-rendering:optimizeLegibility}' + 
				/* 指向图片发光 */
				'.icon{-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}img:hover{box-shadow:0 0 4px 4px rgba(130,190,10,0.6)!important;-moz-transition-property:box-shadow;-moz-transition-duration:.31s}img{-moz-transition-property:box-shadow;-moz-transition-duration:.31s}' +
				/* 文本选中样式 */
				'::selection{background:#333!important;color:#0f0!important}::-moz-selection{background:#333!important;color:#0f0!important}::-ms-selection{background:#333!important;color:#0f0!important}::-o-selection{background:#333!important;color:#0f0!important}'].join('\n');
				css += ['' + 
				/* 美化滚动条 */
				'::-webkit-resizer,::-webkit-scrollbar-button,::-webkit-scrollbar-corner{display:none!important;max-width:0!important;max-height:0!important;overflow:hidden!important;position:absolute;left:-102030px}::-webkit-scrollbar-track{border-left-color:transparent!important;background:transparent!important;-webkit-box-shadow:none!important;border:none!important;outline:none!important}::-webkit-full-screen{visibility:visible;max-width:none}::-webkit-scrollbar{width:10px;height:10px}::-webkit-scrollbar-track-piece{-webkit-border-radius:10px;background-color:transparent!important}::-webkit-scrollbar-thumb:vertical{height:10px;-webkit-border-radius:10px;background-color:#d0aba8}::-webkit-scrollbar-thumb:horizontal{width:10px;-webkit-border-radius:10px;background-color:#d1ac96}::-webkit-scrollbar-track-piece:no-button,::-webkit-scrollbar-thumb{border-radius:10px;background-color:transparent}::-webkit-scrollbar-thumb:hover{background-color:red}::-webkit-scrollbar-thumb:active{background-color:#4caf50}::-webkit-scrollbar-button:horizontal,::-webkit-scrollbar-button:vertical{width:10px}::-webkit-scrollbar-button:horizontal:end:increment,::-webkit-scrollbar-button:horizontal:start:decrement,::-webkit-scrollbar-button:vertical:end:increment,::-webkit-scrollbar-button:vertical:start:decrement{background-color:transparent!important}::-moz-resizer,::-moz-scrollbar-button,::-moz-scrollbar-corner{display:none!important;max-width:0!important;max-height:0!important;overflow:hidden!important;position:absolute;left:-102030px}::-moz-scrollbar-track{border-left-color:transparent!important;background:transparent!important;-moz-box-shadow:none!important;border:none!important;outline:none!important}::-moz-full-screen{visibility:visible;max-width:none}::-moz-scrollbar{width:10px;height:10px}::-moz-scrollbar-track-piece{-moz-border-radius:10px;background-color:transparent!important}::-moz-scrollbar-thumb:vertical{height:10px;-moz-border-radius:10px;background-color:#d0aba8}::-moz-scrollbar-thumb:horizontal{width:10px;-moz-border-radius:10px;background-color:#d1ac96}::-moz-scrollbar-track-piece:no-button,::-moz-scrollbar-thumb{border-radius:10px;background-color:transparent}::-moz-scrollbar-thumb:hover{background-color:red}::-moz-scrollbar-thumb:active{background-color:#4caf50}::-moz-scrollbar-button:horizontal,::-moz-scrollbar-button:vertical{width:10px}::-moz-scrollbar-button:horizontal:end:increment,::-moz-scrollbar-button:horizontal:start:decrement,::-moz-scrollbar-button:vertical:end:increment,::-moz-scrollbar-button:vertical:start:decrement{background-color:transparent!important}::-ms-resizer,::-ms-scrollbar-button,::-ms-scrollbar-corner{display:none!important;max-width:0!important;max-height:0!important;overflow:hidden!important;position:absolute;left:-102030px}::-ms-scrollbar-track{border-left-color:transparent!important;background:transparent!important;-ms-box-shadow:none!important;border:none!important;outline:none!important}::-ms-full-screen{visibility:visible;max-width:none}::-ms-scrollbar{width:10px;height:10px}::-ms-scrollbar-track-piece{-ms-border-radius:10px;background-color:transparent!important}::-ms-scrollbar-thumb:vertical{height:10px;-ms-border-radius:10px;background-color:#d0aba8}::-ms-scrollbar-thumb:horizontal{width:10px;-ms-border-radius:10px;background-color:#d1ac96}::-ms-scrollbar-track-piece:no-button,::-ms-scrollbar-thumb{border-radius:10px;background-color:transparent}::-ms-scrollbar-thumb:hover{background-color:red}::-ms-scrollbar-thumb:active{background-color:#4caf50}::-ms-scrollbar-button:horizontal,::-ms-scrollbar-button:vertical{width:10px}::-ms-scrollbar-button:horizontal:end:increment,::-ms-scrollbar-button:horizontal:start:decrement,::-ms-scrollbar-button:vertical:end:increment,::-ms-scrollbar-button:vertical:start:decrement{background-color:transparent!important}::-o-resizer,::-o-scrollbar-button,::-o-scrollbar-corner{display:none!important;max-width:0!important;max-height:0!important;overflow:hidden!important;position:absolute;left:-102030px}::-o-scrollbar-track{border-left-color:transparent!important;background:transparent!important;-o-box-shadow:none!important;border:none!important;outline:none!important}::-o-full-screen{visibility:visible;max-width:none}::-o-scrollbar{width:10px;height:10px}::-o-scrollbar-track-piece{-o-border-radius:10px;background-color:transparent!important}::-o-scrollbar-thumb:vertical{height:10px;-o-border-radius:10px;background-color:#d0aba8}::-o-scrollbar-thumb:horizontal{width:10px;-o-border-radius:10px;background-color:#d1ac96}::-o-scrollbar-track-piece:no-button,::-o-scrollbar-thumb{border-radius:10px;background-color:transparent}::-o-scrollbar-thumb:hover{background-color:red}::-o-scrollbar-thumb:active{background-color:#4caf50}::-o-scrollbar-button:horizontal,::-o-scrollbar-button:vertical{width:10px}::-o-scrollbar-button:horizontal:end:increment,::-o-scrollbar-button:horizontal:start:decrement,::-o-scrollbar-button:vertical:end:increment,::-o-scrollbar-button:vertical:start:decrement{background-color:transparent!important}'].join('\n');
				function stylusjiangxiaobai() {
					document.head.insertAdjacentHTML("beforeend", '<style id = "jiangxiaobaizitimeihua" type = "text/css" media = "all" class = "stylus">' + (css) + "</style>")
				};
				try {
					var stylusjiangxiaobaicss = document.querySelector("style#jiangxiaobaizitimeihua");
					if (stylusjiangxiaobaicss) {} else {
						stylusjiangxiaobai()
					}
				} catch (err) {
					stylusjiangxiaobai()
				}
			}
		}
	} catch (err) {
		return false
	}
}(Object);